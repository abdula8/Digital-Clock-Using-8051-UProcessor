#ifndef PORT_H
#define PORT_H

sbit edit_mode=P3^0;
sbit pause=P0^3;
sbit dgt_slct=P3^2;
sbit dgt_ncrmnt=P3^3;

#define Seg_Control P1
#define Seg_Data P2


#endif
