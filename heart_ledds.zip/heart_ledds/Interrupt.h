#ifndef INT_H
#define INT_H

#define InterruptEX0 0
#define InterruptTimer0 1
#define InterruptEX1 2
#define InterruptTimer1 3
#define InterruptSerial 4
#define InterruptTimer2 5



#endif