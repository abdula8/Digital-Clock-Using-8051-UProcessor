#ifndef DATATYPES_H
#define DATATYPES_H

typedef enum {false=0, true=1} boolean;

// Typedefs
typedef unsigned char tByte;
typedef unsigned int tWord;
typedef unsigned long tLong;


#endif