#ifndef Delay_H
#define Delay_H

#include "DataTypes.h"

void Delay_1ms();
void Delay_ms(tWord);
void Delay_s(tWord);
void delay_Timer();

#endif
