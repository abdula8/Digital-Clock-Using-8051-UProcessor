#ifndef PORTS_H
#define PORTS_H

#define LedsPort P2
sbit Ex0Pin = P3^2; 
sbit Ex1Pin = P3^3;
sbit led_9=P1^2;

#endif